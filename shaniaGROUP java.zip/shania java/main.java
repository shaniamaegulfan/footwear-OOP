import java.util.Scanner;

// Pricing interface with the calculatePrice method
interface Pricing {
    void calculatePrice();
}

// Parent class Footwear implementing the Pricing interface
abstract class Footwear implements Pricing {
    
    
    private String name;
    private int size;
    private String material;
    private double price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price){
        this.price = price;
    }

    public abstract void calculatePrice(); // Abstraction - method to calculate price

    // Constructor
    public Footwear(String name, int size, String material) {
        this.name = name;
        this.size = size;
        this.material = material;
    }
}
      
// Child class Shoes inheriting from Footwear
class Shoes extends Footwear {
    public Shoes(String name, int size, String material) {
        super(name, size, material);
    }

    // Polymorphism - calculate price for shoes
    @Override
    public void calculatePrice() {
        // calculate price for shoes
        double basePrice = 50.0;
        double sizeMultiplier = getSize() * 1.5;
        double materialMultiplier = getMaterial().equalsIgnoreCase("leather") ? 2.0 : 1.0;
        double totalPrice = basePrice + sizeMultiplier * materialMultiplier;
        setPrice(totalPrice);
    }
}

// Child class Sandal inheriting from Footwear
class Sandal extends Footwear {
    public Sandal(String name, int size, String material) {
        super(name, size, material);
    }

    // Polymorphism - calculate price for sandals
    @Override
    public void calculatePrice() {
        // Some specific logic to calculate price for sandals
        double basePrice = 30.0;
        double sizeMultiplier = getSize() * 1.2;
        double materialMultiplier = getMaterial().equalsIgnoreCase("rubber") ? 1.5 : 1.0;
       double totalPrice = basePrice + sizeMultiplier * materialMultiplier;
        setPrice(totalPrice);
    }
}

// Child class Slipper inheriting from Footwear
class Slipper extends Footwear {
    public Slipper(String name, int size, String material) {
        super(name, size, material);
    }

    // Polymorphism - calculate price for slippers
    @Override
    public void calculatePrice() {
        // Some specific logic to calculate price for slippers
        double basePrice = 20.0;
        double sizeMultiplier = getSize() * 1.0;
        double materialMultiplier = getMaterial().equalsIgnoreCase("foam") ? 1.2 : 1.0;
        double totalPrice = basePrice + sizeMultiplier * materialMultiplier;
        setPrice(totalPrice);
    }
}

// Main class for interaction with the user
public class main {
    public static void main(String[] args) {
        // Get user input for footwear type, size, and material
        Scanner scanner = new Scanner(System.in);

        System.out.println(" \n");
        System.out.print("Enter the  name of the customer:");
        String name=scanner.nextLine();
        System.out.println(" \n\n");
        System.out.println("       * Welcome  "+name+ " to Genggeng's Footwear Shop.");
        System.out.println("Enjoy shopping to our glamorous varìous footwears");
        System.out.println("yet affordable*");
        System.out.println(" \n\n");
        System.out.println("Footwears: ");
        System.out.println("• Shoes");
        System.out.println("• Sandal");
        System.out.println("• Slipper");
             
        System.out.print("Enter the type of footwear you want to buy:  ");
        String userFootwearType = scanner.nextLine();

        System.out.print("Enter the size: ");
        int userSize = scanner.nextInt();

        scanner.nextLine(); // Consume the newline character
        System.out.println("This are the available materials: ");
        System.out.println("• Leather");
        System.out.println("• Rubber");
        System.out.println("• Foam");
        System.out.print("Enter the material you like: ");
        String userMaterial = scanner.nextLine();

        scanner.close(); // Close the scanner to prevent resource leak

        // Create the appropriate footwear object based on user input
        Footwear userFootwear;
        switch (userFootwearType.toLowerCase()) { // Convert to lowercase for consistent comparison
            case "shoes":
                userFootwear = new Shoes(userFootwearType, userSize, userMaterial);
                break;
            case "sandal":
                userFootwear = new Sandal(userFootwearType, userSize, userMaterial);
                break;
                case "slipper":
                userFootwear = new Slipper(userFootwearType, userSize, userMaterial);
                break;
            default:
                userFootwear = new Shoes("default", 7, "leather"); // Default to shoes if input is invalid
                break;
        }

        // Calculate and print the price
        userFootwear.calculatePrice();
        System.out.println("The price of the " + userFootwearType + " is: P" + userFootwear.getPrice());
        System.out.println(" \n");
        
        System.out.println("Customer's Name: "+name);
        System.out.println("Customer's Footwear: "+userFootwearType);
        System.out.println("Footwear's Size: "+userSize);
        System.out.println("Customer's Total Payment: P"+userFootwear.getPrice());
        System.out.println(" \n");
        System.out.println("                Thank you our dear customer;)");
        System.out.println("                        Come again!");
    }
}-